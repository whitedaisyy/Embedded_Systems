#include "Aufgabe23.h"
#include "Player.h"
#include <string>
#include <cstdlib>

namespace Aufgabe23
{
	void run()
	{
		int anzahlspieler = 0;
		Die standardwuerfel(6, 1);
		cout << "Bitte geben Sie ein zu wie viele Spielern Sie spielen wollen:" << endl;
		cin >> anzahlspieler;
		Player* p_array = new Player[anzahlspieler];
		for (int i = 0; i < anzahlspieler; i++)
		{
			string spielername;
			cout << "Bitte geben Sie den Namen des " << i + 1 << ". Spielers ein:" << endl;
			cin >> spielername;
			p_array[i].setName(spielername);
			p_array[i].setWuerfel(standardwuerfel);
		}
		for (int i = 0; i < anzahlspieler; i++)
		{
			p_array[i].VorsichtvorVerluste(1);
		}

		qsort(p_array, anzahlspieler, sizeof(Player), vergleicheZweiPlayer);

		for (int i = 0; i < anzahlspieler; i++)
		{
			cout << i + 1 << ".Platz ist:" << p_array[i].getname() << "mit einem Score von: " << p_array[i].getScore() << endl;
		}

		delete[] p_array;


		system("pause");
	}
	int vergleicheZweiPlayer(const void* elem1, const  void* elem2) // fuer quicksort, 4. Parameter  
	{
		Player* p1 = (Player*)elem1;
		Player* p2 = (Player*)elem2;
		if (p1->getScore() > p2->getScore())
		{
			return -1;
		}
		else if (p1->getScore() < p2->getScore())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}