/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 1
| Aufgabe: 1
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 2h
|
\*************************************************************************/
#pragma once
class Stack
{
private:
	int _size;   //Groesse des Arrays 
	int _top;    //Index des obersten, noch freien Eintrags
	char* _a;    //Array zur Aufnahme der Stackelemente

public:
	Stack();               //Konstruktoren
	Stack(int groesse);
	~Stack();
	void push(char data);  //Methoden
	char pop();
	bool isEmpty();
	bool isFull();
};