/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 1
| Aufgabe: 1
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 2h
|
\*************************************************************************/
#pragma once
using namespace std;
namespace Aufgabe23
{
	void run();
	int vergleicheZweiPlayer(const void* elem1, const  void* elem2);


}
