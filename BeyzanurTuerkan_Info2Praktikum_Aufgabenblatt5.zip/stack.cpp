#include "stack.h"
#include <iostream>
#include <iomanip>

using namespace std;
Stack::Stack()
{
	_size = 10;                  //Standardkonstruktor mit max. 10 Arrayelemeneten
	_a = new char[_size];        //dem array a wird die size mitgegeben -> array kann nur _size gro� werden
	_top = 0;                    //_top = oberste freie Stelle 
}
Stack::Stack(int groesse)
{
	_size = groesse;              //kein Standradkonstruktor, selbst bestimmen
	_a = new char[_size];
	_top = 0;
}
Stack:: ~Stack()         //Destruktor: l�scht alles vom speicher
{
	delete[]_a;
}
void Stack::push(char data)
{
	if (!isFull())           //abfrage ob voll ist
	{
		_a[_top] = data;    //in der obersten freien stelle des arrays wird das element gespeichert
		_top++;             //oberste freie element wird hochgez�hlt
	}
	else
		cout << "Die maximale Groesse des Arrays wurde erreicht." << endl;
}
char Stack::pop()
{
	if (!isEmpty())     //abfrage ob leer ist
	{
		_top--;             //abstieg zum n�chsten belegten element 
		cout << _a[_top];
		return _a[_top];
	}
	else cout << "Ihr Stack ist leer." << endl;
}
bool Stack::isEmpty()
{
	return _top <= 0;     //leer ists, wenn die oberste freie stelle  kleiner gleich 0 ist, r�ckgabe
}
bool Stack::isFull()
{
	return _top >= _size;   //voll ist, wenn die oberste freie Stelle gr��er ist als die gr��e des arrays
}

