#include <iostream>
#include "stack.h"
using namespace std;

namespace Aufgabe20 {

	void run()
	{
		Stack* Liste = nullptr;  // Zeiger wird angelegt, der zu dem Objekt zeigen wird
		char Datei;             //Variablen
		int Groesse;
		char Auswahl1;
		int Auswahl2;
		int Abbruch = 0;   //Abbruch wird mit 0 initialisiert

		cout << "Wollen Sie die Groesse Ihres Stacks auswaehlen?" << endl;
		cin >> Auswahl1;

		if (Auswahl1 == 'j')      //bei ja, wird gefragt: 
		{
			cout << "Wie gross soll Ihr Stack sein?" << endl;
			cin >> Groesse;
			Liste = new Stack(Groesse); // im Heap gespeichert
		}
		else
		{
			Liste = new Stack; // im Heap gespeichert
		}

		while (Abbruch == 0)
		{
			cout << "Was wollen Sie tun?: \n1.Testen ob der Stack leer ist? \n2.Testen ob der Stack voll ist?" << endl;
			cout << "3.Ein Element im Stack speichern? \n4.Ein Element vom Stack nehmen?" << endl;
			cin >> Auswahl2;

			switch (Auswahl2)
			{
			case 1: {                   //abfrage ob leer
				if (Liste->isEmpty() == true)
				{
					cout << "Ihre Liste ist leer." << endl;
				}
				else
				{
					cout << "In ihren Liste sind Elemente enthalten." << endl;
				}
				break;
			}
			case 2: {           //abfrage ob voll
				if (Liste->isFull() == true)
				{
					cout << "Ihre Liste ist voll." << endl;
				}
				else
				{
					cout << "In ihren Liste koennen noch Elemente gespeichert werden" << endl;
				}
				break;
			}
			case 3: { cout << "Geben Sie ein Element ein:" << endl;            //speichern des elements
				cin >> Datei;
				Liste->push(Datei);
				break;
			}
			case 4: {                             //Ausgabe des Elements
				Liste->pop();
				break;
			}
			default:                             //weder 1,2,3 oder 4
			{	cout << "Okay, schade." << endl;
			Abbruch = 1;
			break;
			}

			}
		}
		delete Liste;            //Liste wird gel�scht
		system("pause");
	}
}