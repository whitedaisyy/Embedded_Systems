#include "Die.h"
#include <iostream>
#include <iomanip>

void Die::setuntereZahl(int unten)
{
	_untereZahl = unten;
}
void Die::setobereZahl(int oben)
{
	_obereZahl = oben;
}
int Die::getuntereZahl()
{
	return _untereZahl;
}
int Die::getobereZahl()
{
	return _obereZahl;
}
int Die::w�rfeln()
{
	int wurf = ((rand() % ((this->getobereZahl() - this->getuntereZahl()) + 1)) + this->getuntereZahl());
	return wurf;
}
void Die::setW�rfelseiten(int array[])
{
	for (int i = 0; i < 6; i++)
	{
		_W�rfelseiten[i] = array[i];
	}
}
int Die::getW�rfelseiten(int a)
{
	return _W�rfelseiten[a];
}
int Die::mitarrayw�rfeln()
{
	int wurf = this->getW�rfelseiten(rand() % 6);
	return wurf;
}