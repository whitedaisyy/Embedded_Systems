/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 4
| Aufgabe: 15
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 45min.
|
\*************************************************************************/
#pragma once
#include <string>

using namespace std;
namespace aufgabe15
{
	class Hund
	{
	private:
		string _name;


	public:
		void bellen(string Wuff = "wau wau");

		Hund(string hundename = "Bello")
		{
			_name = hundename;
		}

	};
	void run();
}