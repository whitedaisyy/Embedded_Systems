/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 1
| Aufgabe: 1
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 2h
|
\*************************************************************************/
#pragma once

using namespace std;

namespace aufgabe19
{
	void run();
}
