#include "aufgabe16.h" 
#include "person.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;
namespace aufgabe16
{

	void run()
	{
		person::person p;
		int auswahl;

		string vorname, mittelname, nachname;

		cout << "Bitte geben Sie ihren Vornamen ein: " << endl;
		cin >> vorname;

		cout << "Bitte geben Sie ihren Mittelnamen ein: " << endl;
		cin >> mittelname;

		cout << "Bitte geben Sie ihren Nachnamen ein " << endl;
		cin >> nachname;

		p.setName(vorname, mittelname, nachname);

		cout << "Wie wollen Sie den Namen ausgeben?: \n 1. Europaeisch \n 2. Vollstaendig \n 3. Amerikanisch \n 4. Amtlich " << endl;
		cin >> auswahl;

		switch (auswahl)
		{
		case 1:
		{
			p.printEuropaeisch();
			break;
		}
		case 2:
		{
			p.printVollstaendig();
			break;
		}
		case 3:
		{
			p.printAmerikanisch();
			break;
		}
		case 4:
		{
			p.printAmtlich();
			break;
		}
		}
		system("pause");
	}
}