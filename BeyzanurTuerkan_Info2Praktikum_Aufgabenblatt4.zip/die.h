/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 1
| Aufgabe: 1
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 2h
|
\*************************************************************************/
#pragma once
#include <iostream>
#include <iomanip>
#include <string>

class Die
{
private:
	int _untereZahl;
	int _obereZahl;
	int _W�rfelseiten[6];
public:
	Die(int oben = 6, int unten = 1)
	{
		_untereZahl = unten;
		_obereZahl = oben;
		for (int i = 0; i < 6; i++)
		{
			_W�rfelseiten[i] = (i + 1);
		}
	}
	Die(int w�rfelseiten[6])
	{
		_untereZahl = 0;
		_obereZahl = 0;
		for (int i = 0; i < 6; i++)
		{
			_W�rfelseiten[i] = w�rfelseiten[i];
		}
	}
	/*Die()
	{
		_untereZahl = 0;
		_obereZahl = 0;
		for (int i = 0; i < 6; i++)
		{
			_W�rfelseiten[i] = (i + 1);
		}
	}*/
	void setW�rfelseiten(int array[]);
	int getW�rfelseiten(int a);
	void setuntereZahl(int unten);
	void setobereZahl(int oben);
	int getuntereZahl();
	int getobereZahl();
	int w�rfeln();
	int mitarrayw�rfeln();
};

