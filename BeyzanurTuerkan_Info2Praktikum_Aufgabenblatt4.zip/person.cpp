#include "person.h" 
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

namespace person
{
	void person::setName(string Vm, string Mm, string Nm)
	{
		vorname = Vm;
		mittelname = Mm;
		nachname = Nm;

	}

	void person::printEuropaeisch()
	{
		cout << vorname << " " << nachname << endl;
	}

	void person::printVollstaendig()
	{
		cout << vorname << " " << mittelname << " " << nachname << endl;
	}

	void person::printAmerikanisch()
	{
		cout << vorname << " " << mittelname[0] << ". " << nachname << endl;
	}

	void person::printAmtlich()
	{
		cout << nachname << ", " << vorname << " " << mittelname << endl;
	}
}