#pragma once/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 1
| Aufgabe: 1
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 2h
|
\*************************************************************************/
#pragma once

using namespace std;

namespace Complex
{
	class Complex
	{
	private:
		int _Realteil;
		int _Imaginaerteil;
	public:
		Complex(int Real = 0, int Imag = 0)
		{
			_Realteil = Real;
			_Imaginaerteil = Imag;
		}
		void setRealteil(int Real);	           //getter und setter, damit der benutzer zugriff auf die funktionen hat
		void setImaginaerteil(int Imag);
		int getRealteil();
		int getImaginaerteil();
		double BetragBerechnen();
		double ArgumentBerechnen();
		void kartesischeAusgabe();
		void exponentielleAusgabe();
		void ComplexAddition(Complex z);
		void ComplexMulti(Complex z);
		Complex Complexkonjugiert();

	};
}