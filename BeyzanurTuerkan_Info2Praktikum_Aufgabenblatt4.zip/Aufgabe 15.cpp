#include "aufgabe15.h"
#include <iostream>
#include <iomanip>
#include <string.h> 

using namespace std;
namespace aufgabe15 {

	void run()
	{
		Hund meinHund;                //kein name, siehe header
		Hund LaurasHund("Bella");     //Name des Hudnes
		Hund MarkusHund("Rollo");
		meinHund.bellen("waef");     //wie er bellen soll
		LaurasHund.bellen("Wuff");
		MarkusHund.bellen();        //falls nichts eingegeben wird, dann siehe header
		system("pause");
	}
	void Hund::bellen(string Wuff)
	{

		cout << Wuff << endl;       //Ausgabe der Funktion, wie er bellt

	}

}