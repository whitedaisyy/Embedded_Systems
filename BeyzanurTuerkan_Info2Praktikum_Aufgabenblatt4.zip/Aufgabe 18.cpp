#include "aufgabe18.h"
#include "Player.h"
#include <iostream>
#include <iomanip>
#include <string>


using namespace std;

namespace aufgabe18
{
	void run()
	{
		srand(time(0));
		string P1Name;
		string P2Name;
		cout << "Wie heisst Spieler 1?" << endl;
		cin >> P1Name;
		cout << endl;
		cout << "Wie heisst Spieler 2?" << endl;
		cin >> P2Name;
		cout << endl;
		Player p1(P1Name);
		Player p2(P2Name);
		bool weiter = true;
		char k = 'a';
		while (weiter)
		{
			p1.gamble();
			p2.gamble();
			int scorep1 = p1.getScore();
			int scorep2 = p2.getScore();

			if (scorep1 > scorep2)
			{
				cout << "Damit hat " << p1.getname() << " gewonen" << endl;
			}
			else if (scorep1 < scorep2)
			{
				cout << "Damit hat " << p2.getname() << " gewonnen" << endl;
			}
			else if (scorep1 == scorep2)
			{
				cout << "Damit ist es Unentschieden" << endl;
			}
			cout << "Wollen Sie noch eine Runde spielen?" << endl;
			cout << "Geben Sie bitte j fuer 'ja' ein. Falls nicht geben Sie n fuer 'nein' ein" << endl;
			cin >> k;
			if (k == 'n')
			{
				weiter = false;
			}
			else if (k == 'j')
			{
				p1.Scorereset();
				p2.Scorereset();
				system("cls");
			}
		}
		system("pause");
	}
}
