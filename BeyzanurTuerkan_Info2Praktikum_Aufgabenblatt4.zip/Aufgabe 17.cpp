#include "Complex.h" 
#include "aufgabe17.h"
#include <iostream>
#include <iomanip>

using namespace std;
namespace aufgabe17
{
	void run()
	{

		Complex::Complex z1(4, 6);
		z1.kartesischeAusgabe();
		Complex::Complex z3 = z1.Complexkonjugiert();
		z3.kartesischeAusgabe();

		Complex::Complex z2 = 2;
		z2.kartesischeAusgabe();
		system("pause");
	}
}