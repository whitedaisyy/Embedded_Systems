/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 4
| Aufgabe: 16
|*************************************************************************|
| Bearbeitungsdauer:
| ca. 1h
|
\*************************************************************************/

#pragma once
#include <string>
using namespace std;
namespace person
{
	class person
	{
	private:
		string vorname;
		string mittelname;
		string nachname;

	public:
		person(string Vm = "Beyza", string Mm = "Nur", string Nm = "Tuerkan")
		{
			vorname = Vm;
			mittelname = Mm;
			nachname = Nm;
		}
		void setName(string Vm, string Mm, string Nm);

		void printEuropaeisch();
		void printVollstaendig();
		void printAmerikanisch();
		void printAmtlich();
	};
}
