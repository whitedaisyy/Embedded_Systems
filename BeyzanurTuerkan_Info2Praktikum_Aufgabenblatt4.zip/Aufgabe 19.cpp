#include "aufgabe19.h"
#include "Player.h"
#include <iostream>
#include <iomanip>
#include <string>
#include<chrono>
#include<thread>


using namespace std;

namespace aufgabe19
{
	void run()
	{
		srand(time(0));
		int ArrayA[] = { 0, 0, 4, 4, 4, 4 };
		int ArrayB[] = { 3, 3, 3, 3, 3, 3 };
		int ArrayC[] = { 2, 2, 2, 2, 6, 6 };
		int ArrayD[] = { 1, 1, 1, 5, 5, 5 };

		Die W�rfelA(ArrayA);
		Die W�rfelB(ArrayB);
		Die W�rfelC(ArrayC);
		Die W�rfelD(ArrayD);

		srand(time(0));
		string P1Name;
		string P2Name;
		cout << "Wie heisst Spieler 1?" << endl;
		cin >> P1Name;
		cout << endl;
		cout << "Wie heisst Spieler 2?" << endl;
		cin >> P2Name;
		cout << endl;
		Player p1(W�rfelD, P1Name);
		Player p2(W�rfelA, P2Name);
		for (int i = 0; i < 1000; i++)
		{
			p1.mitarraygamble();
			p2.mitarraygamble();
			int scorep1 = p1.getScore();
			int scorep2 = p2.getScore();
			int winp1 = p1.getwins();
			int winp2 = p2.getwins();

			if (scorep1 > scorep2)
			{
				cout << "Damit hat " << p1.getname() << " gewonen" << endl;
				winp1++;
				p1.setwins(winp1);
			}
			else if (scorep1 < scorep2)
			{
				cout << "Damit hat " << p2.getname() << " gewonnen" << endl;
				winp2++;
				p2.setwins(winp2);
			}
			else if (scorep1 == scorep2)
			{
				cout << "Damit ist es Unentschieden" << endl;
			}

			p1.Scorereset();
			p2.Scorereset();
			/*this_thread::sleep_for(std::chrono::milliseconds(2000));*/
			system("cls");

		}
		cout << p1.getname() << " hat: " << p1.getwins() << endl;
		cout << p2.getname() << " hat: " << p2.getwins() << endl;
		if (p1.getwins() > p2.getwins())
		{
			cout << "Damit hat " << p1.getname() << " gewonen!" << endl;
		}
		else if (p1.getwins() < p2.getwins())
		{
			cout << "Damit hat " << p2.getname() << " gewonnen!" << endl;
		}
		else if (p1.getwins() == p2.getwins())
		{
			cout << "Damit ist es Unentschieden!" << endl;
		}
		p1.Winreset();
		p2.Winreset();

		system("pause");
	}
}
