/*************************************************************************\
| Autor: Beyza T�rkan, David Stephan
| Aufgabenblatt: 4
| Aufgabe: 18
|*************************************************************************|
| Bearbeitungsdauer:
| ca.
|
\*************************************************************************/
#pragma once
#include <string>
#include "Die.h"

using namespace std;



class Player
{
private:
	int _score;
	void setscore(int score);
	int w�rfeln();
	int mitarrayw�rfeln();
	string _name;
	Die _w�rfel;
	int _wins;
public:
	Player(Die w�rfel, string name = " ", int score = 0)
	{
		_score = score;
		_name = name;
		_w�rfel = w�rfel;
		_wins = 0;
	}
	Player(string name = " ", int score = 0)
	{
		_score = score;
		_name = name;
		_w�rfel = Die(6, 1);
		_wins = 0;
	}
	void mitarraygamble();
	void gamble();
	void VorsichtvorVerluste(int zahl);
	int getScore();
	void setName(string name);
	void Scorereset();
	string getname();
	void setwins(int w);
	int getwins();
	void Winreset();

};