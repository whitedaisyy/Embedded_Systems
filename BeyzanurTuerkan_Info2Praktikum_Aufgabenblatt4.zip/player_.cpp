#include "Player.h"
#include "Die.h"
#include <iostream>
#include <iomanip>
#include <string>



void Player::setscore(int score)
{
	_score = score;
}
int Player::w�rfeln()
{
	return _w�rfel.w�rfeln();
}
int Player::mitarrayw�rfeln()
{
	return _w�rfel.mitarrayw�rfeln();
}
void Player::gamble()
{
	this->VorsichtvorVerluste(5);
}
int Player::getScore()
{
	return _score;
}
void Player::Scorereset()
{
	_score = 0;
}
string Player::getname()
{
	return _name;
}
void Player::setName(string name)
{
	_name = name;
}
void Player::VorsichtvorVerluste(int zahl)
{
	cout << _name << ": ";
	for (int i = 0; i < zahl; i++)
	{
		int wurf = this->w�rfeln();
		_score += wurf;
		cout << wurf << ",  ";
	}
	cout << "Punktestand: " << setw(5) << right << _score << left << endl;
}
//void Player::mitarraygamble()
//{
//	cout << _name << ": ";
//	for (int i = 0; i < 5; i++)
//	{
//		int wurf = this->mitarrayw�rfeln();
//		_score += wurf;
//		cout << wurf << ",  ";
//	}
//	cout << "Punktestand" << setw(5) << _score << endl;
//}
void Player::mitarraygamble()
{
	cout << _name << ": ";
	int wurf = this->mitarrayw�rfeln();
	_score += wurf;
	cout << wurf << ",  ";
	cout << "Punktestand: " << setw(5) << _score << endl;
}
void Player::setwins(int w)
{
	_wins = w;
}
int Player::getwins()
{
	return _wins;
}
void Player::Winreset()
{
	_wins = 0;
}