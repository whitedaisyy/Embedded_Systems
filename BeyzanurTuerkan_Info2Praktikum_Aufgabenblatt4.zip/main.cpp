// Aufgabenblatt1.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
#include <iomanip>
#include <windows.h>
#include <stdlib.h>


#include "Aufgabe1.h"
#include "Aufgabe2.h"
#include "Aufgabe3.h"
#include "Aufgabe4.h"
#include "Aufgabe5.h"
#include "Aufgabe6.h"
#include "Aufgabe7.h"
#include "Aufgabe8.h"
#include "Aufgabe9.h"
#include "Aufgabe11.h"
#include "Aufgabe12.h"
#include "Aufgabe13.h"
#include "Aufgabe14.h"
#include "Aufgabe15.h"
#include "Aufgabe16.h"
#include "Aufgabe17.h"
#include "Aufgabe18.h"
#include "Aufgabe19.h"

using namespace std;

int main()
{
    locale loc;                                   // wegen den Umlauten
    locale::global(locale("German"));

    bool weiter = true;
    while (weiter)
    {
        system("cls");
        cout << "Verfuegbare Aufgaben" << endl;
        cout << "---------------------------------------------------------------" << endl;
        cout << setw(3) << right << 1 << left << " ASCII-Tabelle aufrufen" << endl;
        cout << setw(3) << right << 2 << left << " Zufallsgenerator" << endl;
        cout << setw(3) << right << 3 << left << " Reaktionsspiel" << endl;
        cout << setw(3) << right << 4 << left << " Aegyptische Multiplikation" << endl;
        cout << setw(3) << right << 5 << left << " Zeiger und Referenzen" << endl;
        cout << setw(3) << right << 6 << left << " Verschmelzen von Arrays" << endl;
        cout << setw(3) << right << 7 << left << " C-Strings" << endl;
        cout << setw(3) << right << 8 << left << " Heron-Verfahren" << endl;
        cout << setw(3) << right << 9 << left << " Verkettete Liste" << endl;
        cout << setw(3) << right << 11 << left << " Conways Game of Life" << endl;
        cout << setw(3) << right << 12 << left << " Merge" << endl;
        cout << setw(3) << right << 13 << left << " Vergleich von Sortierverfahren" << endl;
        cout << setw(3) << right << 14 << left << " ISBN-Nummern" << endl;
        cout << setw(3) << right << 15 << left << " Eine Klasse Hund" << endl;
        cout << setw(3) << right << 16 << left << " Eine erste Klasse" << endl;
        cout << setw(3) << right << 17 << left << " Eine Klasse für komplexe Zahlen" << endl;
        cout << setw(3) << right << 18 << left << " Wuerfelspiel" << endl;
        cout << setw(3) << right << 19 << left << " Das Wuerfel-Duell" << endl;
       
        cout << "---------------------------------------------------------------" << endl;
        cout << "Waehle 0 fuer Beenden";
        int i;
        cin >> i;
        switch (i)
        {
        case 0:
            weiter = false;
            break;
        case 1:
            Aufgabe1::main();
            break;
        case 2:
            Aufgabe2::run();
            break;
        case 3:
            Aufgabe3::main();
            break;
        case 4:
            Aufgabe4::main();
            break;
        case 5:
            Aufgabe5::run();
            break;
        case 6:
            Aufgabe6::run();
            break;
        case 7:
            Aufgabe7::run();
            break;
        case 8:
            Aufgabe8::run();
            break;
        case 9:
            Aufgabe9::run();
            break;
        case 11:
            Aufgabe11::run();
            break;
        case 12:
            Aufgabe12::run();
            break;
        case 13:
            Aufgabe13::run();
            break;
       /* case 14:
            Aufgabe14::run();
            break;*/
        case 15:
            aufgabe15::run();
            break;
        case 16:
            aufgabe16::run();
            break;
        case 17:
            aufgabe17::run();
            break;
        case 18:
            aufgabe18::run();
            break;
        case 19:
            aufgabe19::run();
            break;
        default:
            break;
        }
    }
}


// Programm ausführen: STRG+F5 oder Menüeintrag "Debuggen" > "Starten ohne Debuggen starten"
// Programm debuggen: F5 oder "Debuggen" > Menü "Debuggen starten"

// Tipps für den Einstieg: 
//   1. Verwenden Sie das Projektmappen-Explorer-Fenster zum Hinzufügen/Verwalten von Dateien.
//   2. Verwenden Sie das Team Explorer-Fenster zum Herstellen einer Verbindung mit der Quellcodeverwaltung.
//   3. Verwenden Sie das Ausgabefenster, um die Buildausgabe und andere Nachrichten anzuzeigen.
//   4. Verwenden Sie das Fenster "Fehlerliste", um Fehler anzuzeigen.
//   5. Wechseln Sie zu "Projekt" > "Neues Element hinzufügen", um neue Codedateien zu erstellen, bzw. zu "Projekt" > "Vorhandenes Element hinzufügen", um dem Projekt vorhandene Codedateien hinzuzufügen.
//   6. Um dieses Projekt später erneut zu öffnen, wechseln Sie zu "Datei" > "Öffnen" > "Projekt", und wählen Sie die SLN-Datei aus.
