#include "Complex.h" 
#include <iostream>
#include <iomanip>
#include <string>
#include <math.h>

namespace Complex
{
#define PI 3.14159

	void Complex::setRealteil(int Real)
	{
		_Realteil = Real;
	}
	void Complex::setImaginaerteil(int Imag)
	{
		_Imaginaerteil = Imag;
	}
	int Complex::getRealteil()
	{
		return _Realteil;
	}
	int Complex::getImaginaerteil()
	{
		return _Imaginaerteil;
	}
	double Complex::BetragBerechnen()
	{
		double Betrag = sqrt(pow(_Realteil, 2) + pow(_Imaginaerteil, 2));
		return Betrag;

	}
	double Complex::ArgumentBerechnen()
	{
		if (_Realteil >= 0)
		{
			double Argument = atan2(_Realteil, _Imaginaerteil);
			return Argument;
		}
		else if (_Realteil < 0 && _Imaginaerteil >= 0)
		{
			double Argument = atan2(_Realteil, _Imaginaerteil) + PI;
			return Argument;
		}
		else if (_Realteil < 0 && _Imaginaerteil < 0)
		{
			double Argument = atan2(_Realteil, _Imaginaerteil) - PI;
			return Argument;
		}
	}
	void Complex::kartesischeAusgabe()
	{
		/*if (_Imaginaerteil >= 0)
		{*/

		cout << _Realteil << showpos << _Imaginaerteil << "j" << noshowpos << endl;
		/*}
		else if (_Imaginaerteil < 0)
		{
			cout << _Realteil << _Imaginaerteil << "j" << endl;
		}*/
	}
	void Complex::exponentielleAusgabe()
	{
		double betrag = BetragBerechnen();
		double argument = ArgumentBerechnen();
		cout << betrag << "x" << "E^" << argument << "j" << endl;
	}
	void Complex::ComplexAddition(Complex z)
	{
		this->setRealteil(this->getRealteil() + z.getRealteil());
		this->setImaginaerteil(this->getImaginaerteil() + z.getImaginaerteil());
	}
	void Complex::ComplexMulti(Complex z)
	{
		Complex help;
		help.setRealteil((this->getRealteil() * z.getRealteil()) - (this->getImaginaerteil() * z.getImaginaerteil()));
		help.setImaginaerteil((this->getRealteil() * z.getImaginaerteil()) + (this->getImaginaerteil() * z.getRealteil()));

		this->setRealteil(help.getRealteil());
		this->setImaginaerteil(help.getImaginaerteil());

		/*double argument = this->ArgumentBerechnen() + z.ArgumentBerechnen();
		double betrag = this->BetragBerechnen()* z.BetragBerechnen();
		cout << betrag << "x" << "E^" << argument << "j" << endl;*/
	}
	Complex Complex::Complexkonjugiert()
	{
		Complex z;
		z.setRealteil(this->getRealteil());
		z.setImaginaerteil(-this->getImaginaerteil());
		return  z;
	}
