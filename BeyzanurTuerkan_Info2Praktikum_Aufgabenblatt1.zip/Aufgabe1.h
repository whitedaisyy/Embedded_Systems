#pragma once
namespace Aufgabe1
{
	void printHeadline();
	int printDataline();
	void main();
}