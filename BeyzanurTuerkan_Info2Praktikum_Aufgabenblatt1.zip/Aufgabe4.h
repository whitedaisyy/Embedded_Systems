#pragma once
namespace Aufgabe4
{
	int halbiererundverdoppler(int Zahl1, int Zahl2, int& ergebnis);
	void main();
}