#pragma once

namespace Aufgabe2
{
	int run();
	int Aufgabe2a(int a, int b, char c);
	void Aufgabe2b();
}