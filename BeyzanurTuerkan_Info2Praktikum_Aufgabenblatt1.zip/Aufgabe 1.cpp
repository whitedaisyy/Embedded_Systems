#include <iostream>
#include <iomanip>
#include <windows.h>
#include <stdlib.h>
#include "Aufgabe1.h"

using namespace std;
namespace Aufgabe1
{
    void printHeadline()
    {
        cout << left << "Dezimalwert   ASCII-Zeichen   Hexadezimalwert   Oktalwert" << endl;
    }

    int printDataline(int Zahl)
    { 
        cout << left << showbase << setw(14) << dec << Zahl << setw(16) << char(Zahl) << setw(18) << hex << Zahl << setw(20) << oct << Zahl << setw(22) << endl;
        return Zahl++;
    }

    void main()
    {
        printHeadline();
        int i, Zeile = 0;
        for (i = 32; i < 256; i++)
        {
            printDataline(i);
            Zeile++;
            if (Zeile == 23)
            {
                system("pause");             // Ausgabe wird gestoppt
                Zeile = 0;
                printHeadline();
            }
        }
        getchar();
        getchar();
    }
}