#include <iostream>
#include <iomanip>
#include <windows.h>
#include <stdlib.h>
#include "Aufgabe4.h"

using namespace std;
namespace Aufgabe4
{
    int halbiererundverdoppler(int Zahl1, int Zahl2, int& ergebnis)
    {
        if (Zahl2 % 2 != 0)
        {
            ergebnis += Zahl1;
        }
        if (Zahl2 >= 1)
        {
            cout << Zahl1 << "  " << Zahl2 << endl;
            return halbiererundverdoppler(Zahl1 = Zahl1 * 2, Zahl2 = Zahl2 / 2, ergebnis);
        }
        else if (Zahl1 = 0, Zahl2 = 0)
        {
            return 0;
        }
    }

    void main()
    {
        int links, rechts, ergebnis = 0;
        cout << "Geben Sie zwei Werte ein, die zu multiplizieren sind." << endl,
            cin >> links >> rechts;
        cout << "Aegyptische Mulitplikation" << endl;
        cout << links << "  *  " << rechts << endl;
        cout << "-------------------" << endl;

        halbiererundverdoppler(links, rechts, ergebnis);

        cout << "Ergebnis: " << ergebnis << endl;

        getchar();
        getchar();
    }
}