#include <iostream>
#include <iomanip>
#include <windows.h>
#include <stdlib.h>
#include "Aufgabe3.h"

using namespace std;
namespace Aufgabe3
{
    void Test()
    {
        srand(time(0));                                           
        int verzoegerung = rand() % 10 + 1;                       
       
        Sleep(verzoegerung * 1000);                     
        cout << "---------------" << endl;
        float vorher = clock();                                   
        getchar();          
        getchar();                                                 
        float nachher = clock();

        cout << vorher << "..." << nachher << endl;
        float reaktion;
        reaktion = (nachher - vorher) / CLOCKS_PER_SEC * 1000;            
        cout << "Ihre Reaktion:" << reaktion << "Millisekunden" << endl;
    }


    int main()
    {
        char antwort;
        Test();
        cout << "Wollen Sie den Test nochmal durchfuehren?" << endl;
        cout << "Dr�cken Sie j f�r ja und n f�r nein." << endl;
        cin >> antwort;
       

        if (antwort == 'j')
        {
            system("cls");
            main();
        }
        else
        {
            return 0;
        }
    }
}