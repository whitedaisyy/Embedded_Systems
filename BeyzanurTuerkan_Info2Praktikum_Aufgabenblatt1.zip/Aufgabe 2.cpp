#include <iostream>
#include <iomanip>
#include <windows.h>
#include <stdlib.h>
#include "Aufgabe2.h"

using namespace std;
namespace Aufgabe2
{
    int run()
    {
        srand(time(0));
        Aufgabe2b();

        system("pause");
        return 0;

    }
    int Aufgabe2a(int a, int b, char c)
    {
        if (c == 'f')
        {
            cout << "Bitte geben Sie eine Zahl fuer die untere Grenze ein:" << endl;
            cin >> a;
            cout << "Bitte geben Sie eine Zahl fuer die obere Grenze ein" << endl;
            cin >> b;
            cout << endl;
        }

        /*srand(0);*/
        /*srand(time(0));*/
        int z = a + (rand() % (b - a + 1));
        cout << z << endl;
        return z;
    }
    void Aufgabe2b()
    {
        int A[25] = { 0 };
        int z[200] = { 0 };
        for (int i = 0; i < 200; i++)
        {
            z[i] = Aufgabe2a(0, 24, 't');
        }

        for (int i = 0; i <= 24; i++)
        {
            for (int j = 0; j <= 200; j++)
            {
                if (z[j] == i)
                {
                    A[i]++;
                }
            }
        }
        cout << "Ergebnisse des Zufallgenerators:" << endl;
        cout << "--------------------------------------------------" << endl;
        
        for (int i = 0; i <= 24; i++)
        {
            cout << setw(4) << right << "z = " << setw(5) << left << i << ": (" << left << A[i] << ")" << endl;
        }
    }
}