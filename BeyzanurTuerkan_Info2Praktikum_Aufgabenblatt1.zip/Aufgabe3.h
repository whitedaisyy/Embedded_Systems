#pragma once
namespace Aufgabe3
{
	void Test();
	int main();
}