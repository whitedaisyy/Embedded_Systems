#include <iostream>
#include <iomanip>


using namespace std;
namespace Aufgabe5
	
	/* Funktion void sortieren hat die Funktion,
	die angelegten Zeiger im Hauptprogramm nach dem Inhalt der Variablen zu sortieren, ohne die Variablen zu ver�ndern*/
{
	void sortieren(int*& z1Ptr, int*& z2Ptr, int*& z3Ptr)
	{
		int* temp = 0;

		if (z1Ptr > z2Ptr)
		{
			temp = z1Ptr;            //nach if Bedingung, werden Werte vertauscht durch temp
			z1Ptr = z2Ptr;
			z2Ptr = temp;
		}
		if (z1Ptr > z3Ptr)
		{
			temp = z1Ptr;
			z1Ptr = z3Ptr;
			z3Ptr = temp;
		}
		if (z2Ptr > z3Ptr)
		{
			temp = z2Ptr;
			z2Ptr = z3Ptr;
			z3Ptr = temp;
		}
		
	}

		//Hauptprogramm mit angelegten Variablen und Zeigern, Eingabe der drei Werte, Vergleich vor dem Ausf�hren und nach dem Ausf�hren der Funktion, am Ende Sortieren der Zeiger inklusive Inhalt
		void run()
		{
			int a, b, c;
			int* z1Ptr = &a;
			int* z2Ptr = &b;
			int* z3Ptr = &c;



			cout << "Geben Sie drei Zahlen ein:" << endl, cin >> a >> b >> c;
			cout << "Vor der Funktion" << endl << setw(9) << right << "a = " << setw(5) << left << a << setw(9) << right << "b = " << setw(5) << left << b << setw(9) << right << "c = " << setw(5) << left << c << endl << setw(9) << endl << "*z1Ptr = " << setw(5) << left << *z1Ptr << setw(9) << "*z2Ptr = " << setw(5) << left << *z2Ptr << setw(9) << "*z3Ptr = " << setw(5) << left << *z3Ptr << endl;

			sortieren(z1Ptr, z2Ptr, z3Ptr);
			cout << "Nach der Funktion" << endl << setw(9) << right << "a = " << setw(5) << left << a << setw(9) << right << "b = " << setw(5) << left << b << setw(9) << right << "c = " << setw(5) << left << c << endl << setw(9) << endl << "*z1Ptr = " << setw(5) << left << *z1Ptr << setw(9) << "*z2Ptr = " << setw(5) << left << *z2Ptr << setw(9) << "*z3Ptr = " << setw(5) << left << *z3Ptr << endl;
			getchar();
			getchar();
		}
}