#include <iostream>
#include <iomanip>
#include <string.h>           //Bibliothek f�r strlen

using namespace std;
namespace Aufgabe7
	/*Pr�ft F�lle f�r negative Stelle und zu gro�e Stelle und f�gt dann c an der richtigen Stelle i ein*/
{
	char* insertString(const char* s1, char c, int i)
	{
		int laenge = strlen(s1);
		char* s2 = new char[laenge + 1];

		if (i < 0)
		{
			s2[0] = c;
			for (int x = 0; x <= laenge; x++)
			{
				s2[x + 1] = s1[x];
			}
		}
		else if (i > laenge)
		{
			for (int x = 0; x <= laenge; x++)
			{
				s2[x] = s1[x];
			}
			s2[laenge] = c;
			s2[laenge + 1] = c;
		}
		else
		{
			for (int x = 0; x < i; x++)
			{
				s2[x] = s1[x];
			}
			for(int x=i; x<laenge; x++)
			{
				s2[x + 1] = s1[x];
			}
			s2[i] = c;
		}
		return s2;
	}
	/*Eingabe des Wortes, des Zeichens und der Stelle und Ausgabe von s2*/
	void run()
	{
		char c;
		int i = 0;
		cout << "Bitte geben Sie ein Wort ein:" << endl;
		char s1[100];
		cin >> s1;
		cout << "Bitte geben Sie einen Buchstaben ein." << endl;
		cin >> c;
			cout << "Bitte geben Sie eine Zahl ein, an welcher Stelle der Buchstabe eingefuegt werden soll." << endl;
			cin >> i;
			char* s2 = insertString(s1, c, i);
			for (int x =0; x <=strlen(s1); x++)     //Gibt nur vern�nftige Buchstaben aus (h�rt auf, wenn \0 kommt)
			{
						cout << s2[x];
			}
			cout << endl;
			system("pause");
	}
}


