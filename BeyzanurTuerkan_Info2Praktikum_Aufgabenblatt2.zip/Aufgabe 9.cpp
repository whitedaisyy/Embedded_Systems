#include<iostream>
#include<iomanip>
#include "Aufgabe9.h"

using namespace std;
namespace Aufgabe9
{

	void run()
	{
		Listenelement* anker = nullptr;
		int z = 0;
		bool weiter = true;
		while (weiter)
		{

			switch (menu())
			{
			case 1:
				listeausgabe(anker);
				break;
			case 2:
				cout << "Bitte geben Sie ihre Zahl ein: " << endl;
				cin >> z;
				zahlSortiertEinfuegen(anker, z);
				break;
			case 3:
				zufallszahlEinfuegen();
				break;
			case 4:
				laengeBerechnen();
				break;
			case 5:
				testMehrfachZahl();
				break;
			case 9: 
				weiter = false;
				break;
			default:
				;
			}
			system("cls");
		}
		system("pause");
	}

	int menu()
	{
		int i = 0;
		cout << "Was wollen Sie mit der Liste machen?" << endl;
		cout << "1: " << "Ausgeben" << endl;
		cout << "2: " << "Weiter Zahl sortiert einfuegen" << endl;
		cout << "3: " << "Eine Anzahl von Zufallszahlen einfuegen" << endl;
		cout << "4: " << "Laenge bestimmen" << endl;
		cout << "5: " << "Test, ob irgendeine Zahl mehrfach vorkommt" << endl;
		cout << "9: " << "Beenden" << endl;
		cin >> i;
		return i;
	}

	void listeausgabe(Listenelement* tmp)
	{
		while (tmp != nullptr)
		{
			cout << tmp->zahl << "->";
			tmp = tmp->next;
		}
		cout << "Ende der Liste" << endl;
		system("pause");
	}

	void zahlSortiertEinfuegen(Listenelement*& anker, int zahl)
	{
		Listenelement* element = new Listenelement;
		element->zahl = zahl;
		element->next = nullptr;

		//falls Liste leer ist: element dem anker zuweisen
		if (anker == nullptr)
		{
			anker = element;
			return;
		}
		//falls das kleinste element vorne anhängen
		if (zahl <= anker->zahl)
		{
			element->next = anker;
			anker = element;
			return;
		}
		Listenelement* hilfe;
		hilfe = anker;

		//Durch die Liste laufen bis zum letzten Element		
		while (hilfe->next != nullptr)
		{
			//element vor dem nächsten einfügen
			if (element->zahl < hilfe->next->zahl)
			{
				element->next = hilfe->next;
				hilfe->next = element;
				return;
			}
			hilfe = hilfe->next;
		}
		//hinten einfügen
		hilfe->next = element;
	}
	void zufallszahlEinfuegen()
	{

	}
	void laengeBerechnen()
	{

	}
	void testMehrfachZahl()
	{

	}

}