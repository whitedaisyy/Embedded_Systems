#include <iostream>
#include <iomanip>
#include <istream>

using namespace std;
namespace Aufgabe8
{
	/*Heron-Verfahren f�r 5 Durchl�ufe auf 8 Nachkommastellen genau*/
	//Teilaufgabe a)
	double heron(double x)
	{
		double y = x;

		cout << "Die Wurzel aus Ihrer Zahl ist nach dem Heron-Verfahren: " << setprecision(8) << endl;

		for (int i = 0; i < 5; i++)
		{
			y = 0.5 * (y + (x / y));
		}
		return y;
	}
	
	/*Heron-Verfahren maximal 10 Schritte abh�ngig von Genauigkeit --> Benutzer gibt Genauigkeit ein*/
	//Teilaufgabe b)
	double heron(double x, double e)
	{
		double y = x, Genauigkeit = x, Zwischenwert = x;

		cout << "Die Wurzel aus ihrer Zahl ist nach dem Heron-Verfahren: " << setprecision(8) << endl;
		for (int i = 0; i < 10; i++)
		{
			if (Genauigkeit < e)
			{
				return y;
			}
			else
			{
				y = 0.5 * (y + (x / y));
				Genauigkeit = abs(y - Zwischenwert);
				Zwischenwert = y;
			}
		}
		return y;
	}
	
	/*Heron-Verfahren mit Feedback, d.h. die einzelnen F�lle werden gepr�ft*/
	// Teilaufgabe c)
	int heronRef(double* x, double e)
	{
		double Genauigkeit = *x, Zwischenwert = *x, Startwert = *x;

		if (*x < 0)
		{
			return 2;
		}
		
		for (int i = 1; i <= 10; i++)
		{
			if (i == 10)
		{
			return 1;
		}
			else if (Genauigkeit < e)
			{
			return 0;
			}
			else
			{
				*x = 0.5 * (*x + (Startwert/ *x));
				Genauigkeit = abs(*x - Zwischenwert);
				Zwischenwert = Genauigkeit;
			}
		}
	}
	/*Teilaufgabe c) wird aufgerufen*/
	void run()
	{
		double x, ergebnis, e;

		cout << "Geben Sie eine Zahl ein: " << endl;
		cin >> x;
		cout << "Geben Sie eine Genauigkeit an: " << endl;
		cin >> e;

		ergebnis = heronRef(&x, e);

		cout << "Rueckgabe der Funktion: " << ergebnis << endl;

		if (x > 0)
		{
			cout << "Ihr Ergebnis ist: " << setprecision(8) << x << endl;
		}
		getchar();
		getchar();
	}
}
