#pragma once
namespace Aufgabe7
{
	char* insertSting();
	void run();
}