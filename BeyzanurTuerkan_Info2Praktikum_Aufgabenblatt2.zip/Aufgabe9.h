/*************************************************************************\
| Autor: David Stephan, Beyza Türkan
| Aufgabenblatt: 2
| Aufgabe: 9
|*************************************************************************|
| Bearbeitungsdauer:
| 
|
| Bemerkungen:
| Wie ist es schöner mit System("pause") oder mit getchar();?
| Besser/Übersichtlicher mit zwei rekursive Funktionen?
\*************************************************************************/

#pragma once
using namespace std;
namespace Aufgabe9
{
	struct Listenelement
{
	int zahl;
	Listenelement* next;
};

	void run();
	int menu();
	void listeausgabe(Listenelement* anker);
	void zahlSortiertEinfuegen(Listenelement*& anker, int zahl);
	void zufallszahlEinfuegen();
	void laengeBerechnen();
	void testMehrfachZahl();

}