#pragma once
namespace Aufgabe8
{
	//Teilaufgabe a)
	double heron(double x);
	

	//Teilaufgabe b)
	double heron(double x, double e);
	
	//Teilaufgabe c)
	int heronRef(double* x, double e);
	void run();
}