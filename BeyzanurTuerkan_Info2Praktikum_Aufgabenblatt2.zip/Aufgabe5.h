#pragma once
namespace Aufgabe5
{
	void sortieren();
	void run();
}
