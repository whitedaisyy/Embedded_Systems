#include <iostream>
#include <iomanip>
#include <istream>

using namespace std;
namespace Aufgabe6
{
	/*Diese Funktion f�gt den ersten Teil von array1 in array3 ein, dann f�gt er den array2 komplett ein und dann den letzten Teil von array1 in array3 ein*/
	int* array_verschweissen(int array1[], int array2[], int l1, int l2, int position)
	{
		int* array3 = new int[l1 + l2];
		int j = 0;
		int i = 0;
		for (i; i < position; i++)
		{
			array3[i] = array1[i];
			j++;
		}
		for (position; position < (i + l2); position++)
		{
			array3[position] = array2[i];
			i++;
		}
		for (j; j < l1; j++)
		{
			array3[position] = array1[j];
			position++;
		}
		return array3;
	}
	
	/*Arrays angelegt, Ausgabe durch Wahl einer Position und Funktionsaufruf von array_verschweissen, �usgabe von array3*/
	void run()
	{
		int array1[6] = { 7, 3, 5, 9, 6, 2 };
		int array2[8] = { 9, 1, 4, 2, 6, 8, 3, 5 };
		int* array3 = new int[14];
		int position;

		cout << "Geben Sie die Position ein:" << endl;
		cin >> position;

		array3 = array_verschweissen(array1, array2, 6, 8, position);

		for (int i = 0; i < 14; i++)
		{
			cout << array3[i] << " ";
		}
		getchar();
		getchar();
	}
}

