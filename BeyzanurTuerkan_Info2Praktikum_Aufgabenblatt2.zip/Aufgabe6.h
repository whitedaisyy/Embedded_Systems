#pragma once
namespace Aufgabe6
{
	int verschweissen();
	void run();
}