package Aufgabenblatt2;

import hsrt.mec.controldeveloper.core.com.command.IDirection;
import Aufgabenblatt1.Command;

/**
 * Aufgabenblatt 2: Aufgabe 3.2: Bearbeitungsdauer: 30min
 * Bemerkung: Erbt von {@link Aufgabenblatt1.Command}
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */

public class Direction extends Command implements IDirection{

	private int degree = 0;
	
	public Direction(){
		super(IDirection.DIRECTION);
	}

	public void setDegree(int newDegree) {
		if (newDegree < -90) {
			newDegree = -90;
		} else if (newDegree > 90) {
			newDegree = 90;
		}
		degree = newDegree;
	}
	public int getDegree() {
		return degree;
	}
	public String getConfig() {
		return (IDirection.DIRECTION+" "+"- Degree:"+" "+this.getDegree());
	}
}