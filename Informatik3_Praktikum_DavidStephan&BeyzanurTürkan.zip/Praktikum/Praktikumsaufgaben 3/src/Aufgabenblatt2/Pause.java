package Aufgabenblatt2;

import hsrt.mec.controldeveloper.core.com.command.IPause;
import Aufgabenblatt1.Command;

/** 
 * Aufgabenblatt 2: Aufgabe 3.2: Bearbeitungsdauer: 10min
 * Bemerkung: Erbt von {@link Aufgabenblatt1.Command}
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */

public class Pause extends Command implements IPause {
	
	private int duration = 0;
	
	public Pause() {
		super(IPause.PAUSE);
	}
	public void setDuration(int newDuration) {
		duration = newDuration;
	}
	public int getDuration() {
		return duration;
	}
	public String getConfig() {
		return (IPause.PAUSE+" "+"- Duration:"+" "+this.getDuration());
	}
}
