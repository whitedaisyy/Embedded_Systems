
package Aufgabenblatt2;

/** 
 * Aufgabenblatt 2: Aufgabe 3: Bearbeitungsdauer: 10min
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */
public class ControlDeveloper {

	//Klassenvariabel
	public static String ControlDeveloper_Class = "CLASS Control-Developer";
	//Konstante
	public final String ControlDeveloper_Member = "MEMBER Control-Developer";

	public static void main(String s[]) {
		ControlDeveloper cd = new ControlDeveloper();
		String a = ControlDeveloper.ControlDeveloper_Class;
		String d = cd.ControlDeveloper_Member;
		
		cd.getControlDeveloper_Class();
		cd.getControlDeveloper_Member();
	
	}
	public String getControlDeveloper_Class() {
		return ControlDeveloper_Class;
	}
	public String getControlDeveloper_Member() {
		return ControlDeveloper_Member;
	}
}
