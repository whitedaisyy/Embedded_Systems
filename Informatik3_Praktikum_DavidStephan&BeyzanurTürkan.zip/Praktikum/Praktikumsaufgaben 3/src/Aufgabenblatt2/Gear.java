package Aufgabenblatt2;

import hsrt.mec.controldeveloper.core.com.command.IGear;
import Aufgabenblatt1.Command;

/**
 * Aufgabenblatt 2: Aufgabe 3.2: Bearbeitungsdauer: 30min
 * Bemerkung: Erbt von {@link Aufgabenblatt1.Command}
 * @author David Stephan, Beyzanur T�rkan
 * @version 1.0
 */
public class Gear extends Command implements IGear {

	private int speed = 0;
	private int duration = 0;

	public Gear() {
		super(IGear.GEAR);
	}

	public void setSpeed(int newSpeed) {
		if (newSpeed < -100) {
			newSpeed = -100;
		} else if (newSpeed > 100) {
			newSpeed = 100;
		}
		speed = newSpeed;
	}

	public void setDuration(int newDuration) {
		duration = newDuration;
	}
	public int getDuration() {
		return duration;
	}
	public int getSpeed() {
		return speed;
	}
	public String getConfig() {
		return (IGear.GEAR+" "+"- Speed:"+" "+this.getSpeed()+" "+IGear.GEAR+" "+"- Duration:"+" "+ this.getDuration());
	}
}
