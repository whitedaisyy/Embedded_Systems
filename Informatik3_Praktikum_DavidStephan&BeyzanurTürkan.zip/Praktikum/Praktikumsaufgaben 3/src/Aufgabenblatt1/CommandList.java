package Aufgabenblatt1;

import java.util.Vector;

import Aufgabenblatt2.Direction;
import Aufgabenblatt2.Pause;
import hsrt.mec.controldeveloper.core.com.command.ICommand;
import Aufgabenblatt2.Gear;

/**
 * Aufgabenblatt 1: Aufgabe 1: Bearbeitungsdauer: 3 h Bemerkungen: verwaltet die
 * {@link Aufgabenblatt1.Element} mit der root auf dem erstem Element.
 * 
 * @author David Stephan, Beyzanur T�rkan
 * @version 1.0
 * @see Aufgabenblatt1.Command
 */
public class CommandList {

	private Element root;
	/*
	 * public static void main(String s[]) { CommandList cl = new CommandList();
	 * 
	 * //add() f�nf Command mit unterschiedlichem Namen Command c1 = new
	 * Command("Herbert"); Command c2 = new Command("Klaus"); Command c3 = new
	 * Command("Mandrina"); Command c4 = new Command("Shacklin"); Command c5 = new
	 * Command("Kavin (Sohn von Kevin)");
	 * 
	 * System.out.println(" "); System.out.println("nach add()");
	 * 
	 * //add() cl.add(c1); cl.add(c2); cl.add(c3); cl.add(c4); cl.add(c5);
	 * cl.printCommands();
	 * 
	 * // System.out.println(" "); // System.out.println("nach getSize()"); // //
	 * //getSize() // System.out.println(cl.getSize()); // //
	 * System.out.println(" "); // System.out.println("nach get Element"); // //
	 * //getElement() // System.out.println(cl.getElement(0)); //
	 * System.out.println(cl.getElement(1).getCommand().getName()); //
	 * System.out.println(cl.getElement(3).getCommand().getName()); //
	 * System.out.println(cl.getElement(5).getCommand().getName()); //
	 * System.out.println(cl.getElement(6)); // // System.out.println(" "); //
	 * System.out.println("nach getPos()"); // // //getPos() //
	 * System.out.println(cl.getPos(c3)); // System.out.println(cl.getPos(null)); //
	 * // System.out.println(" "); // System.out.println("nach getCommand()"); // //
	 * //getCommand() // System.out.println(cl.getCommand(0)); //
	 * System.out.println(cl.getCommand(1).getName()); //
	 * System.out.println(cl.getCommand(3).getName()); //
	 * System.out.println(cl.getCommand(5).getName()); //
	 * System.out.println(cl.getCommand(6)); // // System.out.println(" "); //
	 * System.out.println("Nach moveUp()"); // // //moveUp() // cl.moveUp(0); //
	 * System.out.println(cl.moveUp(1)); // System.out.println(cl.moveUp(3)); //
	 * cl.moveUp(5); // cl.moveUp(6); // cl.printCommands(); // //
	 * System.out.println(" "); // System.out.println("Nach moveDown()"); // //
	 * //moveDown() // cl.moveDown(0); // cl.moveDown(1); // cl.moveDown(3); //
	 * cl.moveDown(5); // cl.moveDown(6); // cl.printCommands(); // //
	 * System.out.println(" "); // System.out.println("Nach remove()"); // //
	 * //remove() // System.out.println(cl.remove(0)); //
	 * System.out.println(cl.remove(1)); // cl.remove(3); // cl.remove(5); //
	 * cl.remove(6); // cl.printCommands(); // // System.out.println(" "); //
	 * System.out.println("Nach clear()"); // // //clear() // // cl.clear(); //
	 * System.out.println(cl.getCommand(0)); //
	 * System.out.println(cl.getCommand(1)); //
	 * System.out.println(cl.getCommand(3)); //
	 * System.out.println(cl.getCommand(5)); //
	 * System.out.println(cl.getCommand(6));
	 * 
	 * }
	 */
	/*
	 * public static void main(String s[]) { CommandList cl = new CommandList();
	 * 
	 * // //1. Mal create Commands // System.out.println("1.Mal create Commands");
	 * // cl.createCommands(); // cl.printCommands(); // // // add() //
	 * System.out.println(" "); // System.out.println("Nach add()"); // cl.add(new
	 * Pause()); // cl.printCommands(); // // //2. Mal create Commands //
	 * System.out.println(" "); // System.out.println("2.Mal create Commands"); //
	 * cl.createCommands(); // cl.printCommands(); // // //Move up //
	 * System.out.println(" "); // System.out.println("Nach MoveUp()"); //
	 * cl.moveUp(3); // cl.printCommands(); }
	 */

	/**
	 * Gibt die Gr��e der Liste zur�ck. Das erste Element ist l. zeigt. Erstes
	 * Element ist 1;
	 * 
	 * @return Anzahl der Elemente
	 */
	public int getSize() {
		Element hilfsElement = root;
		int anzahl = 0;

		while (hilfsElement != null) {
			hilfsElement = hilfsElement.getNext();
			anzahl++;
		}
		return anzahl;

	}

	/**
	 * L�scht die List
	 */
	public void clear() {
		root = null;
	}

	/**
	 * Gibt das Element an der speziellen Position zur�ck.
	 * 
	 * @param position
	 * @return das Elemente an der Position
	 */
	private Element getElement(int position) {

		Element hilfsElement = root;
		// falls die Liste leer ist, return null
		if (position == 0) {
			return null;
		}
		// Geht die Liste bis zu Position durch
		for (int i = 1; i < position; i++) {
			if (hilfsElement != null) {
				hilfsElement = hilfsElement.getNext();
				// falls die Posisiton > als Size der List dann return null;
			} else {
				return null;
			}
		}

		return hilfsElement;
	}

	/**
	 * Bestimmt die Position des Commands falls der Command in der List existiert,
	 * falls nicht, wird -1 zur�ckgegeben. Erstes Element ist 1.
	 * 
	 * @param gesuchterCommand
	 * @return Position des Commands oder -1
	 * @see getSize()
	 */
	public int getPos(Command gesuchterCommand) {
		Element hilfsElement = root;
		int size = this.getSize();
		// Geht die Liste durch
		for (int position = 1; position <= size; position++) {
			if (hilfsElement.getCommand() != gesuchterCommand) {
				hilfsElement = hilfsElement.getNext();
			} else {
				return position;
			}
		}
		return -1;
	}

	/**
	 * Gibt den Comamnd an der speziellen Position zur�ck, indem getElement
	 * aufgerufen wird.
	 * 
	 * @param position
	 * @return den Command an der Position
	 * @see getElement(int position)
	 */
	public Command getCommand(int position) {

		Element hilfsElement = this.getElement(position);
		if (hilfsElement == null) {
			return null;
		}
		return hilfsElement.getCommand();
	}

	/**
	 * F�gt einen Command mit dem entsprechendem Element am Ende der Liste ein und
	 * gibt ihn dann zur�ck.
	 * 
	 * @param hinzugefuegterCommand
	 * @return hinzugefuegterCommand
	 * @see getSize()
	 */
	public Command add(Command hinzugefuegterCommand) {
		Element hilfsElement = root;
		Element neuesElement = new Element(hinzugefuegterCommand);
		int size = this.getSize();
		// Falls Liste leer ist (Spezialfall)
		if (hilfsElement == null) {
			root = neuesElement;
			neuesElement.setPrev(null);
			neuesElement.setNext(null);
			// Normalfall: List ist nicht leer
		} else {
			for (int position = 1; position < size; position++) {
				hilfsElement = hilfsElement.getNext();
			}
			hilfsElement.setNext(neuesElement);
			neuesElement.setPrev(hilfsElement);
			neuesElement.setNext(null);
		}
//		else {
//			return null;
//		}

		return neuesElement.getCommand();
	}

	/**
	 * Entfernt den Command und gibt ihn zur�ck. Falls es nicht funktioniert, dann
	 * return null.
	 * 
	 * @param position
	 * @return Command oder null
	 * @see getElement(int position)
	 */
	public Command remove(int position) {
		// falls die List nicht null ist
		if (root != null) {
			Element hilfsElement = this.getElement(position);
			if (hilfsElement == null) {
				return null;
			}
			Element prev = hilfsElement.getPrev();
			Element next = hilfsElement.getNext();
			// falls hilfsElement das erste Element ist, wird root umgeh�ngt
			if (root == hilfsElement) {
				root = next;
			}
			if (next != null) {
				next.setPrev(prev);
			}
			if (prev != null) {
				prev.setNext(next);
			}
			hilfsElement.setNext(null);
			hilfsElement.setPrev(null);
			return hilfsElement.getCommand();
		} else {
			return null;
		}
	}

	/**
	 * Tauscht das Element an der gew�hlten Position mit dem eins davor: MoveUp. Es
	 * werden au�erdem alle Referenzen umgeh�ngt und alle F�lle beachtet.
	 * 
	 * @param position
	 * @return Den verschobenen Command oder null
	 */
	public Command moveUp(int position) {
		Element hilfsElement = this.getElement(position);
		if (hilfsElement == null) {
			return null;
		}
		Element prev = hilfsElement.getPrev();
		Element next = hilfsElement.getNext();
		// falls das Element an der ersten Stelle ist, kann ich das nicht nach oben
		// moven
		if (prev == null) {
			return null;
			// falls das hilfsElement mit dem ersten Element aus der Liste getauscht wird,
			// dass der root umgeh�ngt werden muss
		} else if (prev.getPrev() == null) {
			prev.setNext(next);
			hilfsElement.setPrev(prev.getPrev());
			prev.setPrev(hilfsElement);
			hilfsElement.setNext(prev);
			// Spezialfall: falls das hilfsElement auch das Ende der Liste ist:
			// wird auf next (in dem Fall null) nicht zugegriffen.
			if (next != null) {
				next.setPrev(prev);
			}
			root = hilfsElement;
			// wenn das Element am Ende der Liste ist
		} else if (next == null) {
			prev.setNext(next);
			hilfsElement.setPrev(prev.getPrev());
			hilfsElement.getPrev().setNext(hilfsElement);
			prev.setPrev(hilfsElement);
			hilfsElement.setNext(prev);
			// "Normalfall: Element ist mittne in der Liste drinne null wird weder nach
			// vorne noch nach hinten nicht erreicht
		} else {
			prev.setNext(next);
			hilfsElement.setPrev(prev.getPrev());
			hilfsElement.getPrev().setNext(hilfsElement);
			prev.setPrev(hilfsElement);
			hilfsElement.setNext(prev);
			next.setPrev(prev);
		}

		return hilfsElement.getCommand();
	}

	/**
	 * Tauscht das Element an der gew�hlten Position mit dem eins danach: MoveDown.
	 * Es werden au�erdem alle Referenzen umgeh�ngt und alle F�lle beachtet.
	 * 
	 * @param position
	 * @return Den verschobenen Command oder null
	 */
	public Command moveDown(int position) {
		Element hilfsElement = this.getElement(position);
		if (hilfsElement == null) {
			return null;
		}
		Element prev = hilfsElement.getPrev();
		Element next = hilfsElement.getNext();
		// falls das hilfsElement am Ende der Liste ist, kann man das hilfsElement nicht
		// noch weiter nach untenverschieben
		if (next == null) {
			return null;
		}
		// falls das Element am Anfang der List ist
		else if (prev == null) {
			hilfsElement.setPrev(next);
			hilfsElement.setNext(next.getNext());
			next.setPrev(prev);
			next.setNext(hilfsElement);
			// Spezialfall: falls das hilfsElement vorletztes Element der Liste ist,
			// muss null nicht zur�ckzeigen
			if (hilfsElement.getNext() != null) {
				hilfsElement.getNext().setPrev(hilfsElement);
			}
			root = next;
		}
		// falls das hilfsElement vorletztes Element der Liste ist
		else if (next.getNext() == null) {
			prev.setNext(next);
			hilfsElement.setPrev(next);
			hilfsElement.setNext(next.getNext());
			next.setPrev(prev);
			next.setNext(hilfsElement);
		}
		// falls das Element mitten in der Liste ist
		else {
			prev.setNext(next);
			hilfsElement.setPrev(next);
			hilfsElement.setNext(next.getNext());
			next.setPrev(prev);
			next.setNext(hilfsElement);
			hilfsElement.getNext().setPrev(hilfsElement);
		}

		return hilfsElement.getCommand();
	}

	/**
	 * Geht die Gr��e der Liste durch mit getSize und gibt dann die Namen der
	 * Commands aus
	 */
	public void printCommands() {
		Element hilfselement = root;
		int size = this.getSize();
		// geht die Liste durch
		for (int i = 0; i < size; i++) {
			System.out.println(hilfselement.getCommand());
			hilfselement = hilfselement.getNext();
		}
	}

	/**
	 * Leer die Liste, erzeugt dann 5 Commands und f�gt diese der Liste hinzu.
	 * 
	 * @see add(Command hinzugefuegterCommand)
	 */
	public void createCommands() {
		this.clear();

		Direction d1 = new Direction();
		Gear g1 = new Gear();
		Pause p1 = new Pause();
		Direction d2 = new Direction();
		Gear g2 = new Gear();

		add(d1);
		add(g1);
		add(p1);
		add(d2);
		add(g2);
	}

	/**
	 * Macht aus der Liste einen Vector
	 * 
	 * @see {@link Aufgabenblatt3.ControlModel}start()
	 */
	public Vector<ICommand> toVector() {
		Vector<ICommand> cVector = new Vector<ICommand>();
		Element hilfselement = root;
		while (hilfselement != null) {
			cVector.add(hilfselement.getCommand());
			hilfselement = hilfselement.getNext();
		}
		return cVector;
	}
}
