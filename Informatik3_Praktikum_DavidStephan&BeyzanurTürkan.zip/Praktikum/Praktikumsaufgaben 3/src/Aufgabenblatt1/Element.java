package Aufgabenblatt1;

/** 
 * Aufgabenblatt 1: Aufgabe 1: Bearbeitungsdauer: 5min.
 * Bemerkungen: 
 * Ein Element hat einen Vorg�nger und einen Nachfolger und verwaltet die {@link Command}.
 * Elemente werden von der {@link CommandList} gesteuert und verwaltet.  
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */

public class Element{

	private Element next;
	private Element prev;
	private Command cmd;

	public Element(Command command) {
		cmd = command;
	}

	public Command getCommand() {
		return cmd;
	}

	public void setNext(Element neuesElement) {
		next = neuesElement;	
	}

	public Element getNext() {
		return next;
	}

	public void setPrev(Element neuesElement) {
		prev = neuesElement;
	}

	public Element getPrev() {
		return prev;
	}
}
