package Aufgabenblatt1;

import hsrt.mec.controldeveloper.core.com.command.ICommand;

/**
 * Aufgabenblatt 1: Aufgabe 1: Bearbeitungsdauer: 2min.
 * Bemerkungen: Ist ein {@link Aufgabenblatt1.Command} mit einem Namen entweder {@link Aufgabenblatt2.Direction}, {@link Aufgabenblatt2.Gear} oder {@link Aufgabenblatt2.Pause}.
 * @author David Stephan, Beyzanur T�rkan 
 * @version 2.0
 * @see Aufgabenblatt1.Command
 */

public abstract class Command implements ICommand {
	
	private String name;

	public Command(String Commandname) {
		name = Commandname;
	}

	public String getName() {
		return name;
	}
	public abstract String getConfig();
	
	public String toString() {
		return getConfig();
	}
}
