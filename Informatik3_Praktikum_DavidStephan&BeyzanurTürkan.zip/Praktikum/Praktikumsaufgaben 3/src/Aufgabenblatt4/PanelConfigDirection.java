package Aufgabenblatt4;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicBorders.SplitPaneBorder;

import Aufgabenblatt1.Command;
import Aufgabenblatt2.Direction;

public class PanelConfigDirection extends PanelCommandConfig {

	private JTextField tDegree = new JTextField();
	private JButton bSave = new JButton("Save");
	private ControlUI cU;

	public PanelConfigDirection(ControlUI cU) {
		this.cU = cU;
		setView();
		setController();
	}

	private void setView() {
		JLabel degreeLabel = new JLabel();
		degreeLabel.setText("Degree :");
		degreeLabel.setFont(ControlUI.GENERALFONT);
		
		JLabel desLabel = new JLabel();
		desLabel.setText("Degree in '�' Wertebereich: [-90, 90] ");
		desLabel.setFont(ControlUI.GENERALFONT);
		
		tDegree.setFont(ControlUI.GENERALFONT);
		tDegree.setPreferredSize(new Dimension(200,20));
		
		bSave.setFont(ControlUI.GENERALFONT);
		
		
		add(degreeLabel);
		add(tDegree);
		add(desLabel);
		add(bSave);
	}

	private void setController() {
		bSave.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// instaceof Direction?
				if (command instanceof Direction) {
					//Command aktualisieren Zahl in das Command speichern
					Direction dcmd = (Direction) command;
					
					String textDegree = tDegree.getText();
					int intDegree = Integer.parseInt(textDegree);
					dcmd.setDegree(intDegree);
					
					cU.updateTableView(command);
				}
			}
		});
	}

	public void update(Command c) {
		command = c;
		if (command instanceof Direction) {
			Direction dcmd = (Direction) command;
			tDegree.setText("" + dcmd.getDegree());
		}
	}
}
