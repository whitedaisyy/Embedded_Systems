package Aufgabenblatt4;

import javax.swing.table.AbstractTableModel;
import Aufgabenblatt1.CommandList;
import Aufgabenblatt3.ControlModel;

public class TableCommandModel extends AbstractTableModel {

	private final String columnNames[] = { "No.", "Command", "Configuration" };
	private CommandList cL;

	public void TabelCommandModel(CommandList cL) {
		this.cL = cL;
	}

	public String getColumnName(int col) {
			return columnNames[col];
	}

	public int getRowCount() {
		return cL.getSize();
	}

	public int getColumnCount() {
		return 3;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return "" + (rowIndex+1);
		case 1:
			return cL.getCommand(rowIndex+1).getName();
		default:
			return cL.getCommand(rowIndex+1).getConfig();
		}
	}
}
