package Aufgabenblatt4;

import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import Aufgabenblatt1.Command;
import Aufgabenblatt2.Direction;
import Aufgabenblatt2.Gear;
import Aufgabenblatt2.Pause;
import Aufgabenblatt3.ControlModel;
import Aufgabenblatt3.ControlModelListener;

public class ControlUI extends JFrame implements ControlModelListener {

	private final PanelCommandConfig panelConfig[] = 
			{new PanelConfigDefault(),
			new PanelConfigDirection(this),
			new PanelConfigGear(this),
			new PanelConfigPause(this) };
	private JTextArea messageArea = new JTextArea();
	private static final int CONFIGDEFAULT = 0;
	private static final int CONFIGDIRECTION = 1;
	private static final int CONFIGGEAR = 2;
	private static final int CONFIGPAUSE = 3;
	private ControlModel cM = ControlModel.getModel();
	private PanelCommandTable pCTa = new PanelCommandTable(cM, this);
	private PanelCommandTypes pCTy = new PanelCommandTypes(cM, this);
	private JSplitPane jSplitTable = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
	public static final Font GENERALFONT = new Font("", 1, 15);

	public static void main(String[] s) {
		ControlUI cU = new ControlUI();
	}

	public ControlUI() {
		cM.addControlModelListener(this);
		setView();
		setController();
		setMenuBar();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setSize(1000, 500);
		setLocation(100, 100);
	}

	private void setView() {
		JSplitPane jSplitMessage = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		messageArea.setEditable(false);
		messageArea.setFont(GENERALFONT);
		jSplitMessage.setDividerSize(5);
		jSplitMessage.setDividerLocation(300);
		jSplitMessage.setEnabled(false);
		add(jSplitMessage);

		JSplitPane jSplitTypes = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		jSplitTypes.setDividerSize(5);
		jSplitTypes.setDividerLocation(150);
		jSplitTypes.setEnabled(false);

		jSplitTable.setDividerLocation(519);
		jSplitTable.setDividerSize(5);
		jSplitTable.setEnabled(false);

		jSplitMessage.setTopComponent(jSplitTypes);
		jSplitMessage.setBottomComponent(messageArea);
		jSplitTypes.setLeftComponent(pCTy);
		jSplitTypes.setRightComponent(jSplitTable);
		jSplitTable.setLeftComponent(pCTa);
		jSplitTable.setRightComponent(panelConfig[CONFIGDEFAULT]);
	}

	private void setController() {
		// TODO keine Menubar also brauch ich das nicht?
	}

	private void setMenuBar() {
		// TODO brauch ich das danna auch nicht?
	}

	public void updateConfigView(Command c) {
		if (c == null) {
			jSplitTable.setRightComponent(panelConfig[CONFIGDEFAULT]);
		} else {
			PanelCommandConfig pCC;
			switch (c.getName()) {
			case Direction.DIRECTION:
				pCC = panelConfig[CONFIGDIRECTION];
				break;
			case Gear.GEAR:
				pCC = panelConfig[CONFIGGEAR];
				break;
			case Pause.PAUSE:
				pCC = panelConfig[CONFIGPAUSE];
				break;
			default:
				pCC = panelConfig[CONFIGDEFAULT];
				break;
			}
			pCC.update(c);
			jSplitTable.setRightComponent(pCC);
		}
	}

	public void updateTableView(Command c) {
		pCTa.updateTable(c);
		// jSplitTable.setDividerLocation(550);
	}

	@Override
	public void messageUpdated(String message) {
		messageArea.setText(message);
	}

	@Override
	public void roverUpdated() {
		pCTa.updateSelectedRover();
	}

}
