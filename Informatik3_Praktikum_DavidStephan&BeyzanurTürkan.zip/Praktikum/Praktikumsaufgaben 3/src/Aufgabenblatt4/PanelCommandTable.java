package Aufgabenblatt4;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import Aufgabenblatt1.Command;
import Aufgabenblatt3.ControlModel;

public class PanelCommandTable extends JPanel implements ListSelectionListener {

	private JButton bRemove = new JButton("Remove");
	private JButton bUP = new JButton("Up");
	private JButton bDown = new JButton("Down");
	private JButton lRover = new JButton("RoverID"); // TODO
	private JButton bStart = new JButton("Start");
	private JButton bStop = new JButton("Stop");
	private JTable tCommands = new JTable();
	private ListSelectionModel lSM;
	private ControlModel cM;
	private ControlUI cU;
	private TableCommandModel tCM;
//	private DefaultTableColumnModel dTCM = new DefaultTableColumnModel();

	public PanelCommandTable(ControlModel cM, ControlUI cU) {
		this.cM = cM;
		this.cU = cU;
		tCM = new TableCommandModel();
		tCommands.setModel(tCM);

		lSM = tCommands.getSelectionModel();
		lSM.addListSelectionListener(this);
		
		setView();
		setController();
	}

	private void setView() {
		setLayout(new BorderLayout());
		add(tCommands, BorderLayout.CENTER);
		
//		for (int i = 0; i <= 2; i++) {
//			TableColumn col = new TableColumn(i);
//			col.setHeaderValue(tCM.getColumnName(i));
//			dTCM.addColumn(col);
//		}
//		
//		JTableHeader jTH = new JTableHeader(dTCM);
//		tCommands.setColumnModel(dTCM);
//		tCommands.setTableHeader(jTH);
		
		tCommands.setPreferredSize(new Dimension(10, 1000));
		tCommands.getColumnModel().getColumn(0).setPreferredWidth(20);
		tCommands.getColumnModel().getColumn(1).setPreferredWidth(100);
		tCommands.getColumnModel().getColumn(2).setPreferredWidth(410);
		tCommands.setRowHeight(20);
		tCommands.setFont(ControlUI.GENERALFONT);
				
		JPanel buttonPanel = new JPanel();
		
		buttonPanel.add(bRemove);
		bRemove.setFont(ControlUI.GENERALFONT);
		buttonPanel.add(bUP);
		bUP.setFont(ControlUI.GENERALFONT);
		buttonPanel.add(bDown);
		bDown.setFont(ControlUI.GENERALFONT);
		buttonPanel.add(lRover);
		lRover.setFont(ControlUI.GENERALFONT);
		buttonPanel.add(bStart);
		bStart.setFont(ControlUI.GENERALFONT);
		buttonPanel.add(bStop);
		bStop.setFont(ControlUI.GENERALFONT);
		
		add(buttonPanel, BorderLayout.SOUTH);
		updateSelectedRover();
	}

	private void setController() {
		bRemove.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = tCommands.getSelectedRow();
				Command cmd = cM.getCommandList().remove(row + 1);
				cU.updateTableView(cmd);
			}
		});
		bUP.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = tCommands.getSelectedRow();
				Command cmd = cM.getCommandList().moveUp(row + 1);
				cU.updateTableView(cmd);
			}
		});
		bDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = tCommands.getSelectedRow();
				Command cmd = cM.getCommandList().moveDown(row + 1);
				cU.updateTableView(cmd);
			}
		});
		lRover.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				updateSelectedRover();
				cU.updateTableView(null);
			}
		});
		bStart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cM.start();
			}
		});
		bStop.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cM.stop();
			}
		});
	}

	public void updateTable(Command c) {
		tCM.fireTableDataChanged();
		int pos = tCommands.getSelectedRow();
		// int pos = cM.getCommandList().getPos(c)-1;
		lSM.setSelectionInterval(pos, pos);
	}

	public void updateSelectedRover() {
		lRover.setText("RoverID: " + cM.getSelectedRoverId());
	}

	public void valueChanged(ListSelectionEvent lSE) {
		// Welcher Command
		int row = tCommands.getSelectedRow();
		// Command ermittlen
		Command cmd = cM.getCommandList().getCommand(row + 1);
		// rechte Fenster �ndern
		cU.updateConfigView(cmd);
	}
}
