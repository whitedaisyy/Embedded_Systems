package Aufgabenblatt4;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Aufgabenblatt1.Command;

public abstract class PanelCommandConfig extends JPanel{
	
	protected Command command;
	
	public abstract void update(Command c);
}
