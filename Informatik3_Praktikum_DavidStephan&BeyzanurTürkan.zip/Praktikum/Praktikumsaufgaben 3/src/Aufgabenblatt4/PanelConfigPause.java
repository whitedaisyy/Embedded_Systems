package Aufgabenblatt4;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Aufgabenblatt1.Command;
import Aufgabenblatt2.Direction;
import Aufgabenblatt2.Gear;
import Aufgabenblatt2.Pause;

public class PanelConfigPause extends PanelCommandConfig {

	private JTextField tDuration = new JTextField();
	private JButton bSave = new JButton("Save");
	private ControlUI cU;

	public PanelConfigPause(ControlUI cU) {
		this.cU = cU;
		setView();
		setController();
	}

	private void setView() {
		JLabel durationLabel = new JLabel();
		durationLabel.setText("Duration :");
		durationLabel.setFont(ControlUI.GENERALFONT);
		
		JLabel desLabelDuration = new JLabel();
		desLabelDuration.setText("Duration in s");
		desLabelDuration.setFont(ControlUI.GENERALFONT);
		
		tDuration.setFont(ControlUI.GENERALFONT);
		tDuration.setPreferredSize(new Dimension(200,20));
		
		bSave.setFont(ControlUI.GENERALFONT);
		
		add(durationLabel);
		add(tDuration);
		add(desLabelDuration);
		add(bSave);
	}

	private void setController() {
		bSave.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Command aktualisieren Zahl in das Command speichern
				if (command instanceof Pause) {
					Pause pcmd = (Pause) command;
					
					String textDuration = tDuration.getText();
					int intDuration = Integer.parseInt(textDuration);
					pcmd.setDuration(intDuration);
					
					cU.updateTableView(command);
				}
			}
		});
	}

	public void update(Command c) {
		command = c;
		if (command instanceof Pause) {
			Pause pcmd = (Pause) command;
			tDuration.setText("" + pcmd.getDuration());
		}
	}
}
