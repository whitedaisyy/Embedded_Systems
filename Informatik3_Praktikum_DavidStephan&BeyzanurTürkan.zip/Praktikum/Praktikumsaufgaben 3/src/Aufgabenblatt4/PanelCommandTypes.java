package Aufgabenblatt4;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.peer.PanelPeer;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import Aufgabenblatt1.Command;
import Aufgabenblatt3.CommandType;
import Aufgabenblatt3.ControlModel;

public class PanelCommandTypes extends JPanel {

	private JList<CommandType> commandTypeList = new JList<CommandType>();
	private JButton bAdd = new JButton("Add");
	private ControlModel cM;
	private ControlUI cU;

	public PanelCommandTypes(ControlModel cM, ControlUI cU) {
		this.cM = cM;
		this.cU = cU;
		setView();
		setController();
	}

	private void setView() {
		setLayout(new BorderLayout());
		add(bAdd, BorderLayout.SOUTH);
		add(commandTypeList, BorderLayout.CENTER);
		commandTypeList.setListData(cM.getCommandType());
		
		commandTypeList.setFont(ControlUI.GENERALFONT);
		bAdd.setFont(ControlUI.GENERALFONT);
	}

	private void setController() {
		bAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//feststellen welches Command ausgew�hlt wurde
				CommandType cT = commandTypeList.getSelectedValue();
				//Command erzeugen
				if (cT == null) {
					return;
				}
				Command cmd = cT.createInstance();
				cM.getCommandList().add(cmd);
				//command der tabelle hinzuf�gen
				cU.updateTableView(cmd);
			}
		});
	}
}
