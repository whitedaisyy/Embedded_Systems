package Aufgabenblatt4;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Aufgabenblatt1.Command;
import Aufgabenblatt2.Direction;
import Aufgabenblatt2.Gear;

public class PanelConfigGear extends PanelCommandConfig {

	private JTextField tSpeed = new JTextField();
	private JTextField tDuration = new JTextField();
	private JButton bSave = new JButton("Save");
	private ControlUI cU;

	public PanelConfigGear(ControlUI cU) {
		this.cU = cU;
		setView();
		setController();
	}

	private void setView() {
		JLabel speedLabel = new JLabel();
		speedLabel.setText("Speed :");
		speedLabel.setFont(ControlUI.GENERALFONT);
		
		JLabel desLabelSpeed = new JLabel();
		desLabelSpeed.setText("Speed in m/s Wertebereich: [-100, 100] ");
		desLabelSpeed.setFont(ControlUI.GENERALFONT);
	
		tSpeed.setFont(ControlUI.GENERALFONT);
		tSpeed.setPreferredSize(new Dimension(200,20));
	
		JLabel durationLabel = new JLabel();
		durationLabel.setText("Duration:");
		durationLabel.setFont(ControlUI.GENERALFONT);
		
		JLabel desLabelDuration = new JLabel();
		desLabelDuration.setText("Duration in s");
		desLabelDuration.setFont(ControlUI.GENERALFONT);
		
		tDuration.setFont(ControlUI.GENERALFONT);
		tDuration.setPreferredSize(new Dimension(200,20));
		
		bSave.setFont(ControlUI.GENERALFONT);
		
		add(speedLabel);
		add(tSpeed);
		add(desLabelSpeed);
		add(durationLabel);
		add(tDuration);
		add(desLabelDuration);
		add(bSave);
	}

	private void setController() {
		bSave.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Command aktualisieren Zahl in das Command speichern
				if (command instanceof Gear) {
					Gear gcmd = (Gear) command;
					
					String textDuration = tDuration.getText();
					int intDuration = Integer.parseInt(textDuration);
					gcmd.setDuration(intDuration);
					
					String textSpeed = tSpeed.getText();
					int intSpeed = Integer.parseInt(textSpeed);
					gcmd.setSpeed(intSpeed);
					
					cU.updateTableView(command);
				}
			}
		});
	}

	public void update(Command c) {
		command = c;
		if (command instanceof Gear) {
			Gear gcmd = (Gear) command;
			tSpeed.setText("" + gcmd.getSpeed());
			tDuration.setText("" + gcmd.getDuration());
		}
	}
}
