package Aufgabenblatt4;

import Aufgabenblatt1.Command;

public class PanelConfigDefault extends PanelCommandConfig {
	
	public void update(Command c) {

	}
}
