package Aufgabenblatt3;

import java.util.Vector;

/**
 * Aufgabenblatt 3: Aufgabe 3.2: Bearbeitungsdauer: 20min.
 * Bemerkung: Schnittstelle f�r {@link ControlModel} und {@link ControlModelListener}.
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */
public class ControlModelRegistry {
	
	private Vector<ControlModelListener> registry = new Vector<ControlModelListener>() ;
	
	public void addControlModelListener(ControlModelListener cML) {
		registry.add(cML);
	}
	public void removeControlModelListener(ControlModelListener cML) {
		registry.remove(cML);
	}
	public void notifyMessageChanged(String message) {
		registry.forEach((listener)->listener.messageUpdated(message));
	}
	public void notifyRoverChanged() {
		for(ControlModelListener listener : registry) {
			listener.roverUpdated();
		}
		
	}
}
