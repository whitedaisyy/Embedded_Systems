package Aufgabenblatt3;

/**
 * Aufgabenblatt 3: Aufgabe 3.2: Bearbeitungsdauer: 1min.
 * Bemerkung: Interface f�r alle ControlModelListener. Tesetklasse: {@link MeinListener}.
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */
public interface ControlModelListener {
	public void messageUpdated(String message);
	public void roverUpdated();
}
