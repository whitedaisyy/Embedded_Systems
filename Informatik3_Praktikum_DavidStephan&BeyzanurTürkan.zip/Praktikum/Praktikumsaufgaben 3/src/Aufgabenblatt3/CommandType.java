package Aufgabenblatt3;

import Aufgabenblatt1.Command;
import Aufgabenblatt2.Gear;
import Aufgabenblatt2.Direction;
import Aufgabenblatt2.Pause;
import hsrt.mec.controldeveloper.core.com.ComHandler;
import hsrt.mec.controldeveloper.core.com.command.IDirection;
import hsrt.mec.controldeveloper.core.com.command.IGear;
import hsrt.mec.controldeveloper.core.com.command.IPause;

/**
 * Aufgabenblatt 3: Aufgabe 3.1: Bearbeitungsdauer: 45min.
 * Bemerkung:
 * @author David Stephan, Beyzanur T�rkan 
 * @version 1.0 
 */
public class CommandType {
	
	private String name;
	
	public CommandType(String name){
		this.name = name;
	}
	public String getName() {
		return name;
	}
	/**
	 * Erzeugt {@link Aufgabenblatt1.Command} anhand dem Namen.
	 * @return der entsprechende Command oder null
	 */
	public Command createInstance() {
		if (getName().equals(IGear.GEAR)) {
			return new Gear();
		}
		else if (getName().equals(IDirection.DIRECTION)) {
			return new Direction();
		}
		else if (getName().equals(IPause.PAUSE)) {
			return new Pause();
		}
		else return null;
	}
	public String toString() {
		return getName();
	}
	
	
	
	
	
}
