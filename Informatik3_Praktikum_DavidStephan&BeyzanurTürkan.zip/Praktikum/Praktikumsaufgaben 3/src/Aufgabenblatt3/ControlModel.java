package Aufgabenblatt3;

import Aufgabenblatt1.CommandList;
import Aufgabenblatt2.Gear;
import Aufgabenblatt2.Direction;
import Aufgabenblatt2.Pause;
import hsrt.mec.controldeveloper.core.com.Rover;
import hsrt.mec.controldeveloper.core.com.RoverHandler;
import hsrt.mec.controldeveloper.core.com.ComHandler;
import hsrt.mec.controldeveloper.core.com.IComListener;
import hsrt.mec.controldeveloper.core.com.command.ICommand;
import hsrt.mec.controldeveloper.core.com.command.IDirection;
import hsrt.mec.controldeveloper.core.com.command.IGear;
import hsrt.mec.controldeveloper.core.com.command.IPause;

/**
 * Aufgabenblatt 3: Aufgabe 3.2: Bearbeitungsdauer: 1 hr.
 * Bemerkung: Klasse, die die Model implementiert und alle wichtige Komponenten beinhaltet.
 * @author David Stephan, Beyzanur T�rkan
 * @version 1.0
 */
public class ControlModel extends ControlModelRegistry implements IComListener {
	private static ControlModel cM = null;
	private CommandType cT[] = 
		{	new CommandType(IGear.GEAR),
			new CommandType(IDirection.DIRECTION),
			new CommandType(IPause.PAUSE) };
	private CommandList cL;
	private Rover selectedRover;	
	
	private ControlModel() {
		cL = new CommandList();
		ComHandler.getInstance().register(this);
	}
	
	public static ControlModel getModel() {
		if (cM == null) {
			cM = new ControlModel();
		}
		return cM;
	}

	public CommandList getCommandList() {
		return cL;
	}

	public CommandType[] getCommandType() {
		return cT;
	}

//	public void readCommands(File f) {
//
//	}
//
//	public void writeCommands(File f) {
//
//	}
	/**
	 * Beginnt die Commands aus der Commandlist and den Rover zu schicken mit Hilfen von {@link ComHandler.start()}.
	 * @return der Wert aus {@link ComHandler}.
	 */
	public boolean start() {
		ComHandler cH = ComHandler.getInstance();
		return cH.start(cL.toVector(), selectedRover);
	}
	/**
	 * Stopt das Senden der Commands aus der Commandlist mit Hilfe von {@link ComHandler.stop()}.
	 * @return der Wert aus {@link ComHandler}.
	 */
	public boolean stop() {
		ComHandler cH = ComHandler.getInstance();
		return cH.stop();
	}
	/**
	 * Setzt den {@link Aufgabenblatt3.ControlModel.selectedRover} auf einen freien Rover.
	 * @see RoverHandler
	 */
	public void setSelectedRover() {
		RoverHandler rH = new RoverHandler();
		Rover[] freeRover = rH.getFreeRover();
		if (freeRover != null) {			
			selectedRover = freeRover[0];
		}
		notifyRoverChanged();
	}
	/**
	 * Gibt die RoverID zur�ck oder null, falls kein Rover selektiert wurde bis jetzt.
	 */
	public String getSelectedRoverId() {
		if (selectedRover != null) {
			return selectedRover.getRoverID();
		}
		else
			return null;
	}
	/**
	 * Vergleicht die Eingabe mit den Klassenvaribalen und ruft dann {@link Aufgabenblatt3.ControlModelListener.notifyMessageChanged()}
	 * auf.
	 * @param Command comHanNum
	 * @see ComHandler
	 */
	public void commandPerformed(ICommand Command, int comHanNum) {
		if (Command != null) {
			switch (comHanNum) {
			case ComHandler.CONNECTION_ERROR:
				notifyMessageChanged("Command " + Command.getName() + " has an CONNECTION_ERROR");
				break;
			case ComHandler.ROVER_FINISH_ICOMMAND:
				notifyMessageChanged("Command " + Command.getName() + " has finished");
				break;
			case ComHandler.ROVER_IS_USED:
				notifyMessageChanged("Command " + Command.getName() + " Rover is used");
				break;
			case ComHandler.ROVER_RUNNING_ICOMMAND:
				notifyMessageChanged("Command " + Command.getName() + " is RUNNING");
				break;
			case ComHandler.SEND_ICOMMAND:
				notifyMessageChanged("Command " + Command.getName() + " has SEND COMMAND");
				break;
			case ComHandler.ROVER_RECEIVE_ICOMMAND:
				notifyMessageChanged("Command " + Command.getName() + " was RECEIVED");
				break;
			default:
				notifyMessageChanged("Unbekannter Befehl empfangen");
				break;
			}
		}

	}
}
