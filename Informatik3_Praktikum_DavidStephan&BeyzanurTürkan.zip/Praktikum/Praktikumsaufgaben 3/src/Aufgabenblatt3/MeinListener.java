package Aufgabenblatt3;

/**
 * Aufgabenblatt 3: Aufgabe 4: Bearbeitungsdauer: 2min. Bemerkung:
 * @author David Stephan, Beyzanur T�rkan
 * @version 1.0
 */
public class MeinListener implements ControlModelListener {

	public static void main(String s[]) {
		//Test
		ControlModel model = ControlModel.getModel();
		MeinListener mL = new MeinListener();
		model.addControlModelListener(mL);
//		model.notifyMessageChanged("s");
//		model.notifyRoverChanged();

		//Abnahme
		model.getCommandList().add(model.getCommandType()[0].createInstance());
		model.getCommandList().add(model.getCommandType()[1].createInstance());
		model.getCommandList().add(model.getCommandType()[2].createInstance());
		model.setSelectedRover();
		model.start();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void messageUpdated(String message) {
		System.out.println(message);
	}

	public void roverUpdated() {
		System.out.println("roverUpdated wurde aufgerufen");
	}

}
